import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import LinearRegression
import random
import json
from tqdm import tqdm
import warnings
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp

warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


class FastLLMEnhancedGA:
    """快速版本的LLM增强遗传算法"""

    def __init__(self, llm_factors=None):
        self.llm_factors = llm_factors or []
        self.population_size = 30  # 减小种群大小
        self.generations = 50  # 减少进化代数
        self.mutation_rate = 0.1
        self.crossover_rate = 0.8
        self.elite_size = 3  # 减小精英数量

        # 基础算子库
        self.operators = ['+', '-', '*', '/']
        self.features = ['open', 'high', 'low', 'close', 'volume', 'pctChg']

        # 预计算的技术指标缓存
        self.precomputed_indicators = {}

    def precompute_common_indicators(self, data):
        """预计算常用技术指标，避免重复计算"""
        print("预计算技术指标...")

        # 基础价格变化
        data = data.copy()
        data['price_change'] = data['close'].pct_change()
        data['price_change_5'] = data['close'].pct_change(5)

        # 移动平均
        for window in [5, 10, 20]:
            data[f'ma_{window}'] = data['close'].rolling(window).mean()
            data[f'volume_ma_{window}'] = data['volume'].rolling(window).mean()

        # 高低区间
        data['high_10'] = data['high'].rolling(10).max()
        data['low_10'] = data['low'].rolling(10).min()
        data['price_position'] = (data['close'] - data['low_10']) / (data['high_10'] - data['low_10'] + 1e-8)

        # 波动率
        data['volatility_20'] = data['price_change'].rolling(20).std()

        # 动量
        data['momentum_5'] = data['close'] / data['close'].shift(5) - 1

        # 填充NaN值
        data = data.fillna(method='bfill').fillna(method='ffill').fillna(0)

        self.precomputed_data = data
        return data

    def generate_initial_population_fast(self):
        """快速生成初始种群"""
        population = []

        # 1. 预定义的优质因子（避免复杂计算）
        predefined_factors = [
            "close / open - 1",  # 日内收益率
            "high / low - 1",  # 波动幅度
            "volume / volume_ma_5",  # 成交量比率
            "close / ma_5 - 1",  # 5日动量
            "close / ma_10 - 1",  # 10日动量
            "price_position",  # 价格位置
            "momentum_5",  # 5日动量
            "volatility_20",  # 波动率
        ]

        # 2. LLM推荐的复合因子（简化版本）
        llm_factors = [
            "momentum_5 * (volume / volume_ma_5)",  # 动量-成交量
            "price_position * volatility_20",  # 位置-波动率
            "(close / ma_5 - 1) / (volatility_20 + 1e-8)",  # 波动率调整动量
            "price_position * momentum_5",  # 位置-动量
        ]

        population.extend(predefined_factors)
        population.extend(llm_factors)

        # 3. 简单随机因子
        simple_factors = [
            "close - ma_10",
            "volume - volume_ma_5",
            "high - low",
            "pctChg",
            "close / high",
            "volume / (high - low + 1e-8)"
        ]

        population.extend(simple_factors)

        # 补充随机因子
        while len(population) < self.population_size:
            population.append(random.choice(simple_factors))

        return population[:self.population_size]

    def evaluate_factor_fast(self, factor_expr, data, target_col='future_return_1'):
        """快速评估因子性能"""
        try:
            # 使用预计算的数据
            if hasattr(self, 'precomputed_data'):
                eval_data = self.precomputed_data
            else:
                eval_data = data

            # 分组计算因子值
            results = []
            sample_dates = eval_data['date'].unique()[:50]  # 只采样50个日期加快计算

            for date in sample_dates:
                date_mask = eval_data['date'] == date
                date_data = eval_data[date_mask]

                if len(date_data) < 5:  # 数据太少跳过
                    continue

                try:
                    # 计算因子值
                    factor_values = self.safe_eval_factor_fast(factor_expr, date_data)
                    returns = date_data[target_col].values

                    # 计算IC
                    valid_mask = ~np.isnan(factor_values) & ~np.isnan(returns)
                    if np.sum(valid_mask) > 5:
                        ic = np.corrcoef(factor_values[valid_mask], returns[valid_mask])[0, 1]
                        results.append((abs(ic), 0))  # 暂时不计算MSE
                except:
                    continue

            if results:
                ics = [r[0] for r in results]
                avg_ic = np.mean(ics)
                # 简化评分：只使用IC值
                score = avg_ic
                return score, avg_ic, 0
            else:
                return 0, 0, 1

        except Exception as e:
            return 0, 0, 1

    def safe_eval_factor_fast(self, expr, data):
        """快速安全计算因子值"""
        try:
            # 创建评估环境
            env = {
                'open': data['open'].values,
                'high': data['high'].values,
                'low': data['low'].values,
                'close': data['close'].values,
                'volume': data['volume'].values,
                'pctChg': data['pctChg'].values,
                'price_change': data.get('price_change', np.zeros(len(data))),
                'ma_5': data.get('ma_5', np.zeros(len(data))),
                'ma_10': data.get('ma_10', np.zeros(len(data))),
                'volume_ma_5': data.get('volume_ma_5', np.zeros(len(data))),
                'price_position': data.get('price_position', np.zeros(len(data))),
                'momentum_5': data.get('momentum_5', np.zeros(len(data))),
                'volatility_20': data.get('volatility_20', np.zeros(len(data))),
            }

            # 替换表达式中的预计算指标
            for key in env:
                expr = expr.replace(key, f'env["{key}"]')

            # 计算因子值
            result = eval(expr, {"__builtins__": {}}, {'env': env})
            return np.array(result)

        except:
            return np.array([np.nan] * len(data))

    def evaluate_population_fast(self, population, data):
        """快速评估整个种群"""
        scores = []
        ics = []

        for factor in tqdm(population, desc="评估因子", leave=False):
            score, ic, _ = self.evaluate_factor_fast(factor, data)
            scores.append(score)
            ics.append(ic)

        return scores, ics

    def crossover_fast(self, parent1, parent2):
        """快速交叉操作"""
        if random.random() < self.crossover_rate:
            # 简单拼接
            if random.random() < 0.5:
                return f"({parent1} + {parent2}) / 2", f"({parent1} - {parent2})"
            else:
                return parent1, parent2
        return parent1, parent2

    def mutate_fast(self, factor):
        """快速变异操作"""
        if random.random() < self.mutation_rate:
            # 简单变异：替换操作符或数值
            mutations = [
                factor.replace('+', '-'),
                factor.replace('-', '+'),
                factor.replace('*', '/'),
                factor.replace('/', '*'),
                factor + ' * 0.5',
                factor + ' * 2.0'
            ]
            return random.choice(mutations)
        return factor

    def evolve_fast(self, data, target_col='future_return_1'):
        """快速进化过程"""
        # 预计算技术指标
        data = self.precompute_common_indicators(data)

        # 初始化种群
        population = self.generate_initial_population_fast()
        best_factors = []
        history = []

        for generation in tqdm(range(self.generations), desc="GA进化"):
            # 快速评估种群
            scores, ics = self.evaluate_population_fast(population, data)

            # 选择精英
            elite_indices = np.argsort(scores)[-self.elite_size:]
            elite_factors = [population[i] for i in elite_indices]
            elite_scores = [scores[i] for i in elite_indices]
            elite_ics = [ics[i] for i in elite_indices]

            # 记录最佳因子
            best_idx = elite_indices[-1]
            best_factors.append({
                'generation': generation,
                'factor': population[best_idx],
                'score': scores[best_idx],
                'ic': ics[best_idx],
                'mse': 0  # 简化版本不计算MSE
            })

            history.append({
                'generation': generation,
                'avg_score': np.mean(scores),
                'best_score': np.max(scores),
                'avg_ic': np.mean(ics),
                'best_ic': np.max(ics),
            })

            # 创建新种群
            new_population = elite_factors.copy()

            # 快速生成后代
            while len(new_population) < self.population_size:
                # 轮盘赌选择
                parents = random.choices(
                    population,
                    weights=[max(s, 0.01) for s in scores],
                    k=2
                )

                child1, child2 = self.crossover_fast(parents[0], parents[1])
                new_population.extend([
                    self.mutate_fast(child1),
                    self.mutate_fast(child2)
                ])

            population = new_population[:self.population_size]

        return best_factors, history


class FastTraditionalGA(FastLLMEnhancedGA):
    """快速传统遗传算法"""

    def generate_initial_population_fast(self):
        """传统GA的初始种群 - 只包含基础因子"""
        population = []

        # 基础因子
        base_factors = [
            "close / open - 1",
            "high / low - 1",
            "volume / volume_ma_5",
            "close / ma_5 - 1",
            "close / ma_10 - 1",
            "price_position",
            "momentum_5",
            "pctChg",
            "close - ma_10",
            "volume - volume_ma_5",
        ]

        population.extend(base_factors)

        # 补充随机因子
        while len(population) < self.population_size:
            population.append(random.choice(base_factors))

        return population[:self.population_size]


def compare_ga_performance_fast(train_df, llm_factors=None):
    """快速比较遗传算法性能"""
    print("开始快速比较遗传算法性能...")

    # 采样数据加快计算（保持横截面关系）
    sample_stocks = train_df['code'].unique()[:50]  # 只取50只股票
    sample_data = train_df[train_df['code'].isin(sample_stocks)].copy()

    print(f"使用 {len(sample_stocks)} 只股票进行快速测试")
    print(f"样本数据量: {len(sample_data)}")

    # 初始化算法
    traditional_ga = FastTraditionalGA()
    llm_enhanced_ga = FastLLMEnhancedGA(llm_factors)

    # 运行传统GA
    print("\n1. 运行传统遗传算法...")
    traditional_best, traditional_history = traditional_ga.evolve_fast(sample_data)

    # 运行LLM增强GA
    print("\n2. 运行LLM增强遗传算法...")
    llm_best, llm_history = llm_enhanced_ga.evolve_fast(sample_data)

    return {
        'traditional': {
            'best_factors': traditional_best,
            'history': traditional_history
        },
        'llm_enhanced': {
            'best_factors': llm_best,
            'history': llm_history
        }
    }


def visualize_comparison_fast(results, save_path='ga_comparison_fast.png'):
    """快速可视化比较结果"""
    traditional_history = results['traditional']['history']
    llm_history = results['llm_enhanced']['history']

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    # 1. IC值对比
    generations = [h['generation'] for h in traditional_history]
    traditional_best_ic = [h['best_ic'] for h in traditional_history]
    llm_best_ic = [h['best_ic'] for h in llm_history]

    ax1.plot(generations, traditional_best_ic, label='传统GA', linewidth=2, marker='o', markersize=3)
    ax1.plot(generations, llm_best_ic, label='LLM增强GA', linewidth=2, marker='s', markersize=3)
    ax1.set_xlabel('进化代数')
    ax1.set_ylabel('最佳IC值')
    ax1.set_title('横截面IC值对比')
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # 2. 最终性能对比
    final_metrics = {
        '传统GA': {
            'IC': traditional_best_ic[-1],
            '最终IC': traditional_best_ic[-1],
        },
        'LLM增强GA': {
            'IC': llm_best_ic[-1],
            '最终IC': llm_best_ic[-1],
        }
    }

    models = ['传统GA', 'LLM增强GA']
    ics = [final_metrics[model]['IC'] for model in models]

    bars = ax2.bar(models, ics, color=['skyblue', 'lightcoral'], alpha=0.7)
    ax2.set_ylabel('IC值')
    ax2.set_title('最终IC值对比')
    ax2.grid(True, alpha=0.3)

    # 在柱状图上添加数值标注
    for bar, ic in zip(bars, ics):
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width() / 2., height + 0.001,
                 f'{ic:.4f}', ha='center', va='bottom')

    # 计算提升百分比
    improvement = (ics[1] - ics[0]) / ics[0] * 100
    ax2.text(0.5, max(ics) * 0.8, f'性能提升: {improvement:+.1f}%',
             ha='center', va='center', fontsize=12,
             bbox=dict(boxstyle="round,pad=0.3", facecolor="yellow", alpha=0.7))

    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()

    return final_metrics


def print_final_results_fast(results, final_metrics):
    """打印最终结果"""
    print("\n" + "=" * 60)
    print("遗传算法性能对比结果（快速版本）")
    print("=" * 60)

    # 最佳因子展示
    traditional_best = results['traditional']['best_factors'][-1]
    llm_best = results['llm_enhanced']['best_factors'][-1]

    print(f"\n传统GA最佳因子:")
    print(f"  表达式: {traditional_best['factor']}")
    print(f"  IC值: {traditional_best['ic']:.4f}")

    print(f"\nLLM增强GA最佳因子:")
    print(f"  表达式: {llm_best['factor']}")
    print(f"  IC值: {llm_best['ic']:.4f}")

    print(f"\n性能对比:")
    ic_improvement = (final_metrics['LLM增强GA']['IC'] - final_metrics['传统GA']['IC']) / final_metrics['传统GA']['IC'] * 100

    print(f"  IC值提升: {ic_improvement:+.2f}%")

    if ic_improvement > 0:
        print("  ✅ LLM增强GA表现更好！")
    else:
        print("  ❌ 传统GA表现更好")


def main_fast():
    """快速版本主函数"""
    # 配置
    DATA_PATH = r"D:\研究生学习\课程\论文写作\大作业\数据"

    try:
        # 1. 加载数据
        print("加载训练数据...")
        train_df = pd.read_csv(f"{DATA_PATH}/csi300_train.csv")
        train_df['date'] = pd.to_datetime(train_df['date'])
        print(f"原始训练数据形状: {train_df.shape}")

        # 2. 定义LLM推荐的因子
        llm_factors = ["动量成交量", "波动率调整", "价格位置动量"]

        # 3. 快速比较遗传算法性能
        start_time = time.time()
        results = compare_ga_performance_fast(train_df, llm_factors)
        end_time = time.time()

        print(f"\n总运行时间: {end_time - start_time:.2f} 秒")

        # 4. 可视化比较结果
        final_metrics = visualize_comparison_fast(results)

        # 5. 打印详细结果
        print_final_results_fast(results, final_metrics)

        # 6. 保存结果
        output_data = {
            'llm_factors': llm_factors,
            'final_metrics': final_metrics,
            'traditional_best_factor': results['traditional']['best_factors'][-1],
            'llm_best_factor': results['llm_enhanced']['best_factors'][-1],
            'running_time': end_time - start_time
        }

        with open('ga_comparison_fast_results.json', 'w', encoding='utf-8') as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)

        print(f"\n结果已保存到 ga_comparison_fast_results.json")

    except Exception as e:
        print(f"程序执行出错: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    import time

    main_fast()