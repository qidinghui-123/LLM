import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.distributions import Categorical
import numpy as np
from rl_base import *
from rl_ppo import *

class FastEnhancedActorNetwork(nn.Module):
    """快速增强Actor网络"""

    def __init__(self, state_dim, action_dim, llm_feature_dim, hidden_dim=64):
        super(FastEnhancedActorNetwork, self).__init__()

        # 简化网络结构
        self.state_net = nn.Linear(state_dim, hidden_dim // 2)
        self.llm_net = nn.Linear(llm_feature_dim, hidden_dim // 2)

        self.fusion_net = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
            nn.Softmax(dim=-1)
        )

    def forward(self, state, llm_factors):
        state_features = F.relu(self.state_net(state))
        llm_features = F.relu(self.llm_net(llm_factors))

        combined = torch.cat([state_features, llm_features], dim=-1)
        return self.fusion_net(combined)


class FastEnhancedCriticNetwork(nn.Module):
    """快速增强Critic网络"""

    def __init__(self, state_dim, llm_feature_dim, hidden_dim=64):
        super(FastEnhancedCriticNetwork, self).__init__()

        self.state_net = nn.Linear(state_dim, hidden_dim // 2)
        self.llm_net = nn.Linear(llm_feature_dim, hidden_dim // 2)

        self.fusion_net = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, state, llm_factors):
        state_features = F.relu(self.state_net(state))
        llm_features = F.relu(self.llm_net(llm_factors))

        combined = torch.cat([state_features, llm_features], dim=-1)
        return self.fusion_net(combined)


class FastLLMEnhancedPPO:
    """快速LLM增强PPO算法"""

    def __init__(self, state_dim, action_dim, llm_factors, lr=1e-3, gamma=0.99,
                 clip_epsilon=0.2, ppo_epochs=3, batch_size=32):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.llm_factors = llm_factors
        self.llm_feature_dim = len(llm_factors)  # 简化：只使用当前值

        self.gamma = gamma
        self.clip_epsilon = clip_epsilon
        self.ppo_epochs = ppo_epochs
        self.batch_size = batch_size

        # 网络
        self.actor = FastEnhancedActorNetwork(state_dim, action_dim, self.llm_feature_dim)
        self.critic = FastEnhancedCriticNetwork(state_dim, self.llm_feature_dim)

        # 优化器
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=lr)

        # 经验缓冲区
        self.memory = deque(maxlen=1000)

    def select_action(self, state, llm_factor_features):
        """选择动作"""
        state_tensor = torch.FloatTensor(state).unsqueeze(0)
        llm_tensor = torch.FloatTensor(llm_factor_features).unsqueeze(0)

        with torch.no_grad():
            action_probs = self.actor(state_tensor, llm_tensor)
            value = self.critic(state_tensor, llm_tensor)

        dist = Categorical(action_probs)
        action = dist.sample()
        log_prob = dist.log_prob(action)

        return action.item(), log_prob.item(), value.item()

    def store_transition(self, state, action, reward, next_state, done, log_prob, value):
        """存储经验"""
        base_state, llm_features = state
        next_base_state, next_llm_features = next_state

        self.memory.append((
            base_state, llm_features, action, reward,
            next_base_state, next_llm_features, done, log_prob, value
        ))

    def update(self):
        """快速更新网络"""
        if len(self.memory) < self.batch_size:
            return

        # 准备批量数据
        batch = list(self.memory)
        states = torch.FloatTensor([x[0] for x in batch])
        llm_features = torch.FloatTensor([x[1] for x in batch])
        actions = torch.LongTensor([x[2] for x in batch])
        rewards = torch.FloatTensor([x[3] for x in batch])
        next_states = torch.FloatTensor([x[4] for x in batch])
        next_llm_features = torch.FloatTensor([x[5] for x in batch])
        dones = torch.BoolTensor([x[6] for x in batch])
        old_log_probs = torch.FloatTensor([x[7] for x in batch])
        old_values = torch.FloatTensor([x[8] for x in batch])

        # 计算回报
        returns = self._compute_returns(rewards, dones)

        # PPO更新
        for _ in range(self.ppo_epochs):
            # 随机采样
            indices = torch.randperm(len(states))

            for start in range(0, len(states), self.batch_size):
                end = start + self.batch_size
                batch_indices = indices[start:end]

                batch_states = states[batch_indices]
                batch_llm = llm_features[batch_indices]
                batch_actions = actions[batch_indices]
                batch_old_log_probs = old_log_probs[batch_indices]
                batch_returns = returns[batch_indices]

                # 计算优势
                current_values = self.critic(batch_states, batch_llm).squeeze()
                advantages = batch_returns - current_values.detach()
                advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

                # 策略损失
                action_probs = self.actor(batch_states, batch_llm)
                dist = Categorical(action_probs)
                new_log_probs = dist.log_prob(batch_actions)

                ratios = torch.exp(new_log_probs - batch_old_log_probs)
                surr1 = ratios * advantages
                surr2 = torch.clamp(ratios, 1 - self.clip_epsilon, 1 + self.clip_epsilon) * advantages
                actor_loss = -torch.min(surr1, surr2).mean()

                # Critic损失
                critic_loss = F.mse_loss(current_values, batch_returns)

                # 更新网络
                self.actor_optimizer.zero_grad()
                actor_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 0.5)
                self.actor_optimizer.step()

                self.critic_optimizer.zero_grad()
                critic_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 0.5)
                self.critic_optimizer.step()

        # 清理内存
        if len(self.memory) > 500:
            for _ in range(100):
                if self.memory:
                    self.memory.popleft()

    def _compute_returns(self, rewards, dones):
        """计算回报"""
        returns = []
        R = 0

        for r, done in zip(reversed(rewards), reversed(dones)):
            if done:
                R = r
            else:
                R = r + self.gamma * R
            returns.insert(0, R)

        return torch.FloatTensor(returns)


class FastLLMEnhancedEnvironment:
    """快速LLM增强环境"""

    def __init__(self, data, llm_factors, lookback_window=10, transaction_cost=0.001):


        self.llm_factors = llm_factors
        self.base_env = FastFactorMiningEnvironment(data, lookback_window, transaction_cost)

        # 预计算LLM特征
        self._precompute_llm_features()

    def _precompute_llm_features(self):
        """预计算LLM特征 - 简化版本"""
        print("预计算LLM特征...")
        llm_feature_data = []

        data = self.base_env.sampled_data
        max_steps = self.base_env.max_steps

        for i in range(self.base_env.lookback_window,
                       self.base_env.lookback_window + max_steps):
            features = []
            for factor in self.llm_factors:
                if factor in data.columns and i < len(data):
                    # 只使用当前值，简化计算
                    current_val = data[factor].iloc[i]
                    features.append(current_val if not np.isnan(current_val) else 0)
                else:
                    features.append(0)

            llm_feature_data.append(features)

        # 标准化
        from sklearn.preprocessing import StandardScaler
        scaler = StandardScaler()
        self.llm_features = scaler.fit_transform(llm_feature_data)
        self.llm_features = np.nan_to_num(self.llm_features, nan=0.0)

        print(f"LLM特征计算完成，形状: {self.llm_features.shape}")

    def _get_state(self):
        """获取状态"""
        base_state = self.base_env._get_state()

        if self.base_env.current_step < len(self.llm_features):
            llm_features = self.llm_features[self.base_env.current_step].copy()
        else:
            llm_features = np.zeros(len(self.llm_factors))

        return base_state, llm_features

    def step(self, action):
        """执行动作"""
        next_base_state, reward, done, info = self.base_env.step(action)

        if self.base_env.current_step < len(self.llm_features):
            next_llm_features = self.llm_features[self.base_env.current_step].copy()
        else:
            next_llm_features = np.zeros(len(self.llm_factors))

        return (next_base_state, next_llm_features), reward, done, info

    def reset(self):
        """重置环境"""
        self.base_env.reset()
        base_state = self.base_env._get_state()

        if len(self.llm_features) > 0:
            llm_features = self.llm_features[0].copy()
        else:
            llm_features = np.zeros(len(self.llm_factors))

        return base_state, llm_features

    @property
    def current_step(self):
        return self.base_env.current_step

    @property
    def done(self):
        return self.base_env.done