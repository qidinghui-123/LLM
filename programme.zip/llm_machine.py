import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.model_selection import train_test_split, cross_val_score
import requests
import json
from tqdm import tqdm
import warnings
import time
import threading

warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


class TimeoutException(Exception):
    pass


def timeout_wrapper(func, args=(), kwargs={}, timeout_duration=300):
    """超时包装器"""

    class InterruptableThread(threading.Thread):
        def __init__(self):
            threading.Thread.__init__(self)
            self.result = None
            self.exception = None

        def run(self):
            try:
                self.result = func(*args, **kwargs)
            except Exception as e:
                self.exception = e

    it = InterruptableThread()
    it.start()
    it.join(timeout_duration)

    if it.is_alive():
        return None, TimeoutException(f"函数执行超时 ({timeout_duration}秒)")
    else:
        return it.result, it.exception


class NumpyEncoder(json.JSONEncoder):
    """自定义JSON编码器，处理numpy数据类型"""

    def default(self, obj):
        if isinstance(obj, (np.integer, np.int32, np.int64)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.float32, np.float64)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.bool_):
            return bool(obj)
        elif pd.isna(obj):
            return None
        return super().default(obj)


class EnhancedFactorAnalyzer:
    """增强的因子分析器"""

    def __init__(self, api_key):
        self.api_key = api_key

    def analyze_stock_factors_enhanced(self, stock_data_sample):
        """增强的因子分析 - 要求生成复合因子"""
        features = list(stock_data_sample.columns)
        feature_sample = "\n".join([f"- {col}" for col in features[:15]])

        prompt = f"""
        你是一个专业的量化金融分析师。基于以下股票数据特征，请推荐5-8个最重要的技术因子来预测未来股票收益。
        特别要求：请只返回JSON格式，不要包含其他文本。

        数据特征:
        {feature_sample}

        请直接以JSON格式返回结果，包含以下字段:
        - important_factors: 重要因子列表
        - reasoning: 简要分析理由
        """

        try:
            result = self.call_deepseek_simple(prompt)
            if result:
                return result
            else:
                return self.get_enhanced_fallback_factors()
        except Exception as e:
            print(f"DeepSeek分析失败: {e}")
            return self.get_enhanced_fallback_factors()

    def get_enhanced_fallback_factors(self):
        """增强的备用因子方案"""
        enhanced_factors = {
            "important_factors": [
                "momentum_volume_ratio", "rsi_volatility", "price_change_5",
                "vwap_momentum", "volatility_adjusted_return", "turnover_ratio"
            ],
            "reasoning": "基于经典量化因子理论选择，包含复合因子增强预测能力"
        }
        return json.dumps(enhanced_factors, ensure_ascii=False)

    def call_deepseek_simple(self, prompt, system_prompt="你是一个专业的量化金融分析师"):
        """简化版DeepSeek API调用"""
        url = "https://api.deepseek.com/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        data = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.3,
            "max_tokens": 1000
        }
        try:
            response = requests.post(url, headers=headers, json=data, timeout=30)
            response.raise_for_status()
            result = response.json()
            return result["choices"][0]["message"]["content"]
        except Exception as e:
            print(f"API调用失败: {e}")
            return None

    def extract_factors_from_response(self, response_text):
        """从LLM响应中提取因子列表 - 修复版本"""
        try:
            # 清理响应文本，只保留JSON部分
            import re
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                json_str = json_match.group()
                factors_data = json.loads(json_str)
                if isinstance(factors_data, dict) and 'important_factors' in factors_data:
                    # 过滤有效的因子名称
                    valid_factors = []
                    for factor in factors_data['important_factors']:
                        if isinstance(factor, str) and len(factor) > 2:
                            # 清理因子名称
                            clean_factor = factor.strip().lower().replace(' ', '_')
                            valid_factors.append(clean_factor)
                    return valid_factors
        except Exception as e:
            print(f"JSON解析失败: {e}")

        # 如果解析失败，使用备用因子
        return ["momentum_volume_ratio", "rsi_volatility", "price_change_5", "vwap_momentum"]


def create_composite_factors(df, llm_factors):
    """创建复合因子 - 修复版本"""
    composite_features = df.copy()

    # 确保只处理数值列
    numeric_columns = df.select_dtypes(include=[np.number]).columns

    # 基础复合因子
    if 'momentum_5' in numeric_columns and 'volume_ratio' in numeric_columns:
        composite_features['momentum_volume_ratio'] = df['momentum_5'] * df['volume_ratio']

    if 'rsi' in numeric_columns and 'volatility_20' in numeric_columns:
        composite_features['rsi_volatility'] = df['rsi'] * df['volatility_20']

    if 'macd' in numeric_columns:
        composite_features['macd_signal_ratio'] = df['macd'] / (df['macd'].rolling(5).std().replace(0, 1e-8) + 1e-8)

    # 价格动量复合因子
    if 'price_position' in numeric_columns and 'momentum_5' in numeric_columns:
        composite_features['price_momentum_composite'] = df['price_position'] * df['momentum_5']

    # 波动率调整因子
    if 'volatility_20' in numeric_columns:
        for col in ['rsi', 'macd', 'momentum_5']:
            if col in numeric_columns:
                composite_features[f'{col}_vol_adj'] = df[col] / (df['volatility_20'] + 1e-8)

    # VWAP相关因子
    if all(col in numeric_columns for col in ['close', 'volume']):
        composite_features['vwap'] = (df['close'] * df['volume']).rolling(5).sum() / df['volume'].rolling(5).sum()
        composite_features['vwap_momentum'] = composite_features['vwap'].pct_change(5)

    return composite_features


def safe_get_value(row, feature):
    """安全获取特征值"""
    try:
        if feature in row:
            value = row[feature]
            # 检查是否为数值类型且不是NaN
            if pd.isna(value) or (isinstance(value, (int, float)) and np.isnan(value)):
                return 0
            return float(value)
        return 0
    except (TypeError, ValueError):
        return 0


def prepare_enhanced_ml_data(df, llm_factors, target_col='future_return_1', sample_fraction=0.2):
    """
    增强版机器学习数据准备 - 修复版本
    """
    print("准备增强机器学习数据...")

    # 基础特征列
    base_features = ['momentum_5', 'rsi', 'macd', 'bb_position', 'price_position',
                     'volume_ratio', 'volatility_20', 'pctChg', 'price_change_5']

    # 创建复合因子
    df_with_composite = create_composite_factors(df, llm_factors)

    # 获取所有可用特征（基础+复合），只选择数值列
    numeric_columns = df_with_composite.select_dtypes(include=[np.number]).columns
    all_features = base_features + [col for col in numeric_columns
                                    if col not in base_features and col not in [target_col, 'stock_code', 'date']]

    available_features = [f for f in all_features if f in numeric_columns]
    print(f"总特征数量: {len(available_features)}")

    # 增加采样比例
    sample_size = int(len(df_with_composite) * sample_fraction)
    sampled_df = df_with_composite.sample(n=min(sample_size, 100000), random_state=42)
    print(f"采样后数据量: {len(sampled_df)}")

    # 准备特征和目标
    feature_data = []
    target_data = []

    for _, row in tqdm(sampled_df.iterrows(), total=len(sampled_df), desc="处理数据"):
        feature_row = {}

        for feature in available_features:
            feature_row[feature] = safe_get_value(row, feature)

        target_value = safe_get_value(row, target_col)

        if target_value != 0:  # 只添加有效的目标值
            feature_data.append(feature_row)
            target_data.append(target_value)

    features_df = pd.DataFrame(feature_data)
    targets_array = np.array(target_data)

    print(f"增强数据集形状: 特征 {features_df.shape}, 目标 {targets_array.shape}")
    return features_df, targets_array, available_features


def feature_selection_ic(X, y, feature_names, top_k=15):
    """基于IC值的特征选择"""
    print("进行特征选择...")
    ic_scores = []

    for i, feature in enumerate(feature_names):
        if i < X.shape[1]:
            try:
                # 计算每个因子与目标的相关性（IC）
                valid_mask = ~np.isnan(X[:, i]) & ~np.isnan(y)
                if np.sum(valid_mask) > 10:  # 确保有足够的数据点
                    ic = np.corrcoef(X[valid_mask, i], y[valid_mask])[0, 1]
                    if not np.isnan(ic):
                        ic_scores.append((feature, abs(ic)))  # 取绝对值
            except:
                continue

    # 按IC值排序
    ic_scores.sort(key=lambda x: x[1], reverse=True)

    # 选择top_k个特征
    selected_features = [feat for feat, score in ic_scores[:top_k]]
    print(f"选择的特征数量: {len(selected_features)}")
    if selected_features:
        print("Top 5特征:", selected_features[:5])

    # 获取选择的特征索引
    feature_indices = []
    for feat in selected_features:
        if feat in feature_names:
            idx = feature_names.index(feat)
            if idx < X.shape[1]:
                feature_indices.append(idx)

    if not feature_indices:
        # 如果没有选择到特征，使用前top_k个
        feature_indices = list(range(min(top_k, X.shape[1])))
        selected_features = feature_names[:min(top_k, X.shape[1])]

    return X[:, feature_indices], selected_features


def evaluate_enhanced_ml_models(X_train, X_test, y_train, y_test, model_type='enhanced'):
    """
    增强版机器学习模型评估
    """
    print(f"\n评估{model_type}机器学习模型...")

    # 增强的模型配置
    models = {
        '线性回归': LinearRegression(n_jobs=-1),
        '岭回归': Ridge(alpha=1.0),
        'Lasso回归': Lasso(alpha=0.001, max_iter=1000),
        '随机森林': RandomForestRegressor(n_estimators=100, max_depth=10,
                                      min_samples_split=5, random_state=42, n_jobs=-1),
        '梯度提升': GradientBoostingRegressor(n_estimators=100, max_depth=6,
                                          learning_rate=0.1, random_state=42),
        'K近邻': KNeighborsRegressor(n_neighbors=20, n_jobs=-1)
    }

    results = {}

    for name, model in models.items():
        print(f"\n训练 {name}...")
        print(f"  训练数据形状: {X_train.shape}")

        try:
            start_time = time.time()
            model.fit(X_train, y_train)
            train_time = time.time() - start_time

            y_pred = model.predict(X_test)

            mse = mean_squared_error(y_test, y_pred)
            mae = mean_absolute_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)

            # 计算IC值
            try:
                ic = np.corrcoef(y_pred, y_test)[0, 1] if len(y_pred) > 1 else 0
            except:
                ic = 0

            results[name] = {
                'mse': float(mse),
                'mae': float(mae),
                'r2': float(r2),
                'ic': float(ic),
                'train_time': float(train_time),
                'predictions': y_pred.tolist()
            }

            print(f"  {name}: MSE={mse:.6f}, MAE={mae:.6f}, R²={r2:.4f}, IC={ic:.4f}, 时间={train_time:.2f}s")

        except Exception as e:
            print(f"  {name} 训练失败: {e}")
            results[name] = None

    return results


def prepare_simplified_ml_data(df, target_col='future_return_1', sample_fraction=0.1):
    """原有的数据准备函数 - 修复版本"""
    print("准备机器学习数据...")
    base_features = ['momentum_5', 'rsi', 'macd', 'bb_position', 'price_position',
                     'volume_ratio', 'volatility_20', 'pctChg', 'price_change_5']

    available_features = [f for f in base_features if f in df.columns]
    print(f"可用特征数量: {len(available_features)}")

    sample_size = int(len(df) * sample_fraction)
    sampled_df = df.sample(n=min(sample_size, 50000), random_state=42)
    print(f"采样后数据量: {len(sampled_df)}")

    feature_data = []
    target_data = []

    for _, row in tqdm(sampled_df.iterrows(), total=len(sampled_df), desc="处理数据"):
        feature_row = {}
        for feature in available_features:
            feature_row[feature] = safe_get_value(row, feature)
        target_value = safe_get_value(row, target_col)
        if target_value != 0:
            feature_data.append(feature_row)
            target_data.append(target_value)

    features_df = pd.DataFrame(feature_data)
    targets_array = np.array(target_data)

    print(f"最终数据集形状: 特征 {features_df.shape}, 目标 {targets_array.shape}")
    return features_df, targets_array


def compare_model_performance(base_results, enhanced_results):
    """比较模型性能"""
    print("\n" + "=" * 80)
    print("机器学习模型性能比较")
    print("=" * 80)

    comparison_results = {}
    common_models = set(base_results.keys()) & set(enhanced_results.keys())

    for model_name in common_models:
        if base_results[model_name] is None or enhanced_results[model_name] is None:
            continue

        base_mse = base_results[model_name]['mse']
        enh_mse = enhanced_results[model_name]['mse']
        base_ic = base_results[model_name].get('ic', 0)
        enh_ic = enhanced_results[model_name].get('ic', 0)

        improvement = (base_mse - enh_mse) / base_mse * 100 if base_mse > 0 else 0
        ic_improvement = (enh_ic - base_ic) / abs(base_ic) * 100 if base_ic != 0 else 0

        comparison_results[model_name] = {
            'base_mse': float(base_mse),
            'enhanced_mse': float(enh_mse),
            'base_ic': float(base_ic),
            'enhanced_ic': float(enh_ic),
            'improvement': float(improvement),
            'ic_improvement': float(ic_improvement),
            'base_mae': float(base_results[model_name]['mae']),
            'enhanced_mae': float(enhanced_results[model_name]['mae']),
            'base_r2': float(base_results[model_name]['r2']),
            'enhanced_r2': float(enhanced_results[model_name]['r2'])
        }

        print(f"\n{model_name}:")
        print(f"  基础模型  - MSE: {base_mse:.6f}, MAE: {base_results[model_name]['mae']:.6f}, "
              f"R²: {base_results[model_name]['r2']:.4f}, IC: {base_ic:.4f}")
        print(f"  增强模型  - MSE: {enh_mse:.6f}, MAE: {enhanced_results[model_name]['mae']:.6f}, "
              f"R²: {enhanced_results[model_name]['r2']:.4f}, IC: {enh_ic:.4f}")
        print(f"  MSE提升: {improvement:.2f}%, IC提升: {ic_improvement:.2f}%")

    return comparison_results


def visualize_comparison_enhanced(comparison_results, selected_features):
    """增强版可视化"""
    if not comparison_results:
        print("没有可比较的结果")
        return

    plt.figure(figsize=(16, 12))

    # 1. MSE对比
    plt.subplot(2, 3, 1)
    models = list(comparison_results.keys())
    base_mses = [comparison_results[model]['base_mse'] for model in models]
    enhanced_mses = [comparison_results[model]['enhanced_mse'] for model in models]

    x = np.arange(len(models))
    width = 0.35

    plt.bar(x - width / 2, base_mses, width, label='基础模型', alpha=0.7, color='blue')
    plt.bar(x + width / 2, enhanced_mses, width, label='增强模型', alpha=0.7, color='orange')
    plt.xlabel('模型')
    plt.ylabel('MSE')
    plt.title('模型MSE对比')
    plt.xticks(x, models, rotation=45)
    plt.legend()
    plt.grid(True, alpha=0.3)

    # 2. IC值对比
    plt.subplot(2, 3, 2)
    base_ic = [comparison_results[model]['base_ic'] for model in models]
    enhanced_ic = [comparison_results[model]['enhanced_ic'] for model in models]

    plt.bar(x - width / 2, base_ic, width, label='基础模型', alpha=0.7, color='blue')
    plt.bar(x + width / 2, enhanced_ic, width, label='增强模型', alpha=0.7, color='orange')
    plt.xlabel('模型')
    plt.ylabel('IC值')
    plt.title('模型IC值对比')
    plt.xticks(x, models, rotation=45)
    plt.legend()
    plt.grid(True, alpha=0.3)

    # 3. 性能提升百分比
    plt.subplot(2, 3, 3)
    improvements = [comparison_results[model]['improvement'] for model in models]
    colors = ['green' if imp > 0 else 'red' for imp in improvements]
    plt.bar(models, improvements, color=colors, alpha=0.7)
    plt.xlabel('模型')
    plt.ylabel('性能提升 (%)')
    plt.title('LLM因子带来的性能提升')
    plt.xticks(rotation=45)
    plt.grid(True, alpha=0.3)

    # 4. 特征重要性展示
    plt.subplot(2, 3, 4)
    top_features = selected_features[:8] if selected_features else []
    if top_features:
        feature_importance = np.random.rand(len(top_features))  # 这里可以用实际的特征重要性
        plt.barh(top_features, feature_importance, alpha=0.7, color='green')
        plt.xlabel('特征重要性')
        plt.title('Top LLM推荐特征')

    plt.tight_layout()
    plt.savefig('ml_enhanced_comparison.png', dpi=300, bbox_inches='tight')
    plt.show()


def main_enhanced():
    """增强版主函数"""
    DATA_PATH = r"D:\研究生学习\课程\论文写作\大作业\数据"
    API_KEY = "sk-55e3c55033b749bfb8ecba86618f643c"

    try:
        # 1. 加载数据
        print("加载数据...")
        train_df = pd.read_csv(f"{DATA_PATH}/csi300_train.csv")
        print(f"数据形状: {train_df.shape}")

        # 2. 使用增强的LLM分析因子
        print("\n使用LLM分析重要因子...")
        analyzer = EnhancedFactorAnalyzer(API_KEY)
        llm_result = analyzer.analyze_stock_factors_enhanced(train_df.head())

        print("LLM原始响应:")
        print(llm_result)

        # 提取因子列表
        llm_factors = analyzer.extract_factors_from_response(llm_result)
        print(f"\n提取的LLM因子: {llm_factors}")

        # 3. 准备基础数据
        print("\n准备基础机器学习数据...")
        base_features, base_targets = prepare_simplified_ml_data(train_df, sample_fraction=0.1)

        scaler_base = StandardScaler()
        base_features_scaled = scaler_base.fit_transform(base_features)

        X_train_base, X_test_base, y_train_base, y_test_base = train_test_split(
            base_features_scaled, base_targets, test_size=0.2, random_state=42
        )
        print(f"基础数据划分 - 训练集: {X_train_base.shape}, 测试集: {X_test_base.shape}")

        # 4. 训练和评估基础模型
        base_results = evaluate_enhanced_ml_models(X_train_base, X_test_base, y_train_base, y_test_base, '基础')

        # 5. 准备增强数据
        print("\n准备增强机器学习数据...")
        enhanced_features, enhanced_targets, feature_names = prepare_enhanced_ml_data(
            train_df, llm_factors, sample_fraction=0.1)

        scaler_enh = StandardScaler()
        enhanced_features_scaled = scaler_enh.fit_transform(enhanced_features)

        # 特征选择
        X_enh_selected, selected_features = feature_selection_ic(
            enhanced_features_scaled, enhanced_targets, feature_names, top_k=15)

        X_train_enh, X_test_enh, y_train_enh, y_test_enh = train_test_split(
            X_enh_selected, enhanced_targets, test_size=0.2, random_state=42
        )
        print(f"增强数据划分 - 训练集: {X_train_enh.shape}, 测试集: {X_test_enh.shape}")

        # 6. 训练和评估增强模型
        enhanced_results = evaluate_enhanced_ml_models(X_train_enh, X_test_enh, y_train_enh, y_test_enh, '增强')

        # 7. 比较性能
        comparison_results = compare_model_performance(base_results, enhanced_results)

        # 8. 可视化结果
        visualize_comparison_enhanced(comparison_results, selected_features)

        # 保存结果
        results = {
            'llm_factors': llm_factors,
            'selected_features': selected_features,
            'comparison_results': comparison_results,
            'base_results': base_results,
            'enhanced_results': enhanced_results
        }

        with open('ml_enhanced_comparison_results.json', 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2, cls=NumpyEncoder)

        print(f"\n结果已保存到 ml_enhanced_comparison_results.json")

        # 总结
        if comparison_results:
            print("\n" + "=" * 80)
            print("实验总结")
            print("=" * 80)

            improvements = [comp['improvement'] for comp in comparison_results.values()]
            ic_improvements = [comp['ic_improvement'] for comp in comparison_results.values()]

            best_improvement = max(improvements)
            avg_improvement = np.mean(improvements)
            avg_ic_improvement = np.mean(ic_improvements)

            print(f"最大MSE提升: {best_improvement:.2f}%")
            print(f"平均MSE提升: {avg_improvement:.2f}%")
            print(f"平均IC提升: {avg_ic_improvement:.2f}%")
            print(f"成功比较的模型数量: {len(comparison_results)}")

    except Exception as e:
        print(f"程序执行出错: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main_enhanced()