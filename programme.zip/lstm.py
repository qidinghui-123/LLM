import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error
import requests
import json
from tqdm import tqdm
import warnings

warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


class DeepSeekFactorAnalyzer:
    def __init__(self, api_key):
        self.api_key = api_key

    def analyze_stock_factors(self, stock_data_sample):
        """使用DeepSeek分析股票因子 - 改进版本"""
        # 构建数据描述
        features = list(stock_data_sample.columns)
        feature_sample = "\n".join([f"- {col}" for col in features[:10]])

        prompt = f"""
        你是一个专业的量化金融分析师。请基于以下股票数据特征，推荐5-10个最重要的技术因子来预测未来股票收益。

        数据特征:
        {feature_sample}

        请直接以JSON格式返回结果，包含以下字段:
        - important_factors: 重要因子列表
        - reasoning: 简要分析理由
        """

        try:
            result = self.call_deepseek_simple(prompt)
            if result:
                return result
            else:
                return self.get_fallback_factors()
        except Exception as e:
            print(f"DeepSeek分析失败: {e}")
            return self.get_fallback_factors()

    def call_deepseek_simple(self, prompt, system_prompt="你是一个专业的量化金融分析师"):
        """简化版DeepSeek API调用"""
        url = "https://api.deepseek.com/v1/chat/completions"

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }

        data = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.3,
            "max_tokens": 1000
        }

        try:
            response = requests.post(url, headers=headers, json=data, timeout=30)
            response.raise_for_status()
            result = response.json()
            return result["choices"][0]["message"]["content"]
        except Exception as e:
            print(f"API调用失败: {e}")
            return None

    def get_fallback_factors(self):
        """备用因子方案"""
        fallback_factors = {
            "important_factors": [
                "momentum_5", "rsi", "macd", "bb_position", "price_position",
                "volume_ratio", "volatility_20", "pctChg", "price_change_5"
            ],
            "reasoning": "基于经典量化因子理论选择"
        }
        return json.dumps(fallback_factors, ensure_ascii=False)

    def extract_factors_from_response(self, response_text):
        """从LLM响应中提取因子列表"""
        try:
            # 首先尝试直接解析JSON
            factors_data = json.loads(response_text)
            if isinstance(factors_data, dict) and 'important_factors' in factors_data:
                return factors_data['important_factors']
        except:
            # 如果JSON解析失败，尝试从文本中提取
            pass

        # 从文本中提取因子名称
        factors = []
        lines = response_text.split('\n')
        for line in lines:
            line_lower = line.lower()
            # 检查是否包含常见因子关键词
            factor_keywords = ['momentum', 'rsi', 'macd', 'volume', 'volatility',
                               'bb_position', 'price_position', 'pctchg']

            for keyword in factor_keywords:
                if keyword in line_lower:
                    # 尝试提取具体的因子名称
                    words = line.split()
                    for word in words:
                        clean_word = word.strip('",.:;!?()[]{}')
                        if clean_word in ['momentum_5', 'rsi', 'macd', 'bb_position',
                                          'price_position', 'volume_ratio', 'volatility_20',
                                          'pctChg', 'price_change_5']:
                            factors.append(clean_word)

        # 去重并返回
        factors = list(set(factors))
        return factors if factors else ['momentum_5', 'rsi', 'macd', 'bb_position', 'price_position']


def calculate_ic_series(df):
    """计算IC时间序列"""
    print("计算IC时间序列...")
    dates = sorted(df['date'].unique())
    ic_series = []

    # 基础因子列表
    base_factors = ['momentum_5', 'rsi', 'macd', 'bb_position', 'price_position']
    available_factors = [f for f in base_factors if f in df.columns]
    print(f"可用因子数量: {len(available_factors)}")

    for i in tqdm(range(1, len(dates)), desc="计算IC"):
        current_date = dates[i]
        prev_date = dates[i - 1]

        # 前一日因子数据
        prev_data = df[df['date'] == prev_date]
        # 当前日收益率数据
        current_data = df[df['date'] == current_date]

        if len(prev_data) > 10 and len(current_data) > 10:
            # 计算横截面IC
            ic_values = []
            for factor in available_factors:
                try:
                    # 计算该因子的IC值
                    merged = pd.merge(
                        prev_data[['code', factor]],
                        current_data[['code', 'future_return_1']],
                        on='code'
                    )
                    if len(merged) > 10:
                        ic = merged[factor].corr(merged['future_return_1'])
                        if not np.isnan(ic):
                            ic_values.append(ic)
                except:
                    continue

            if len(ic_values) > 0:
                ic_series.append({
                    'date': current_date,
                    'ic_value': np.mean(ic_values)
                })

    ic_df = pd.DataFrame(ic_series)
    print(f"生成的IC序列长度: {len(ic_df)}")
    return ic_df


class ICSequenceDataset(Dataset):
    """IC序列数据集"""

    def __init__(self, ic_series, sequence_length=20):
        self.ic_series = ic_series
        self.sequence_length = sequence_length
        self.scaler = StandardScaler()

        ic_values = ic_series['ic_value'].values.reshape(-1, 1)
        self.scaled_ic = self.scaler.fit_transform(ic_values).flatten()

    def __len__(self):
        return len(self.scaled_ic) - self.sequence_length

    def __getitem__(self, idx):
        x = self.scaled_ic[idx:idx + self.sequence_length]
        y = self.scaled_ic[idx + self.sequence_length]
        return torch.FloatTensor(x), torch.FloatTensor([y])

    def inverse_transform(self, scaled_data):
        return self.scaler.inverse_transform(scaled_data.reshape(-1, 1)).flatten()


class BaseLSTMModel(nn.Module):
    """基础LSTM模型"""

    def __init__(self, input_size=1, hidden_size=32, num_layers=2, output_size=1, dropout=0.2):
        super(BaseLSTMModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        self.lstm = nn.LSTM(input_size, hidden_size, num_layers,
                            batch_first=True, dropout=dropout)
        self.fc = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        lstm_out, _ = self.lstm(x)
        last_output = lstm_out[:, -1, :]
        return self.fc(self.dropout(last_output))


class EnhancedLSTMModel(nn.Module):
    """增强LSTM模型（使用LLM因子）"""

    def __init__(self, input_size=1, hidden_size=32, num_layers=2, output_size=1,
                 factor_size=5, dropout=0.2):
        super(EnhancedLSTMModel, self).__init__()

        # IC序列的LSTM
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers,
                            batch_first=True, dropout=dropout)

        # 因子处理网络
        self.factor_net = nn.Sequential(
            nn.Linear(factor_size, hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size // 2, hidden_size // 4),
            nn.ReLU()
        )

        # 融合网络
        self.fusion_net = nn.Sequential(
            nn.Linear(hidden_size + hidden_size // 4, hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size // 2, output_size)
        )

    def forward(self, x, factors):
        # 处理IC序列
        lstm_out, _ = self.lstm(x)
        seq_features = lstm_out[:, -1, :]

        # 处理LLM因子
        factor_features = self.factor_net(factors)

        # 特征融合
        combined = torch.cat([seq_features, factor_features], dim=1)
        return self.fusion_net(combined)


def train_and_evaluate_model(model, train_loader, val_loader, test_loader, test_dataset, model_type='base'):
    """训练和评估模型 - 进一步优化版本"""
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.0005, weight_decay=1e-5)  # 降低学习率
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=50)  # 使用余弦退火

    train_losses = []
    val_losses = []
    best_val_loss = float('inf')
    patience = 20  # 增加耐心值
    patience_counter = 0
    min_epochs = 30  # 增加最小训练轮次

    print(f"开始训练{model_type}模型，数据加载器长度 - 训练: {len(train_loader)}, 验证: {len(val_loader)}")

    for epoch in range(100):
        # 训练阶段
        model.train()
        epoch_train_loss = 0
        num_train_batches = 0

        for batch in train_loader:
            if model_type == 'base':
                x, y = batch
                # 检查数据有效性
                if torch.isnan(x).any() or torch.isnan(y).any():
                    continue

                optimizer.zero_grad()
                output = model(x.unsqueeze(-1))
                loss = criterion(output, y.unsqueeze(-1))
            else:
                x, factors, y = batch
                # 检查数据有效性
                if torch.isnan(x).any() or torch.isnan(factors).any() or torch.isnan(y).any():
                    continue

                optimizer.zero_grad()
                output = model(x.unsqueeze(-1), factors)
                loss = criterion(output, y.unsqueeze(-1))

            # 检查损失是否有效
            if torch.isnan(loss) or torch.isinf(loss):
                continue

            loss.backward()
            # 添加梯度裁剪防止梯度爆炸
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=0.5)
            optimizer.step()
            epoch_train_loss += loss.item()
            num_train_batches += 1

        # 计算平均训练损失
        if num_train_batches > 0:
            avg_train_loss = epoch_train_loss / num_train_batches
            train_losses.append(avg_train_loss)
        else:
            avg_train_loss = 0
            train_losses.append(0)
            print(f"Epoch {epoch + 1}: 没有有效的训练批次")

        # 验证阶段
        model.eval()
        epoch_val_loss = 0
        num_val_batches = 0

        with torch.no_grad():
            for batch in val_loader:
                if model_type == 'base':
                    x, y = batch
                    if torch.isnan(x).any() or torch.isnan(y).any():
                        continue
                    output = model(x.unsqueeze(-1))
                    loss = criterion(output, y.unsqueeze(-1))
                else:
                    x, factors, y = batch
                    if torch.isnan(x).any() or torch.isnan(factors).any() or torch.isnan(y).any():
                        continue
                    output = model(x.unsqueeze(-1), factors)
                    loss = criterion(output, y.unsqueeze(-1))

                if not (torch.isnan(loss) or torch.isinf(loss)):
                    epoch_val_loss += loss.item()
                    num_val_batches += 1

        # 计算平均验证损失
        if num_val_batches > 0:
            avg_val_loss = epoch_val_loss / num_val_batches
            val_losses.append(avg_val_loss)
        else:
            avg_val_loss = float('inf')
            val_losses.append(float('inf'))
            print(f"Epoch {epoch + 1}: 没有有效的验证批次")

        # 学习率调度
        scheduler.step()

        # 早停机制 - 只在达到最小轮次后启用
        if epoch >= min_epochs:
            if avg_val_loss < best_val_loss:
                best_val_loss = avg_val_loss
                patience_counter = 0
                torch.save(model.state_dict(), f'best_{model_type}_model.pth')
                print(f"Epoch {epoch + 1}: 保存最佳模型，验证损失: {avg_val_loss:.6f}")
            else:
                patience_counter += 1
                # 如果验证损失上升但训练损失下降，可能是过拟合，但也可能只是正常波动
                if patience_counter >= patience // 2:
                    current_lr = optimizer.param_groups[0]['lr']
                    optimizer.param_groups[0]['lr'] = current_lr * 0.8  # 动态调整学习率
                    print(f"Epoch {epoch + 1}: 验证损失未改善，降低学习率到 {optimizer.param_groups[0]['lr']:.6f}")

            if patience_counter >= patience:
                print(f"早停在第 {epoch + 1} 轮，最佳验证损失: {best_val_loss:.6f}")
                break
        else:
            # 在最小轮次内也保存模型
            if avg_val_loss < best_val_loss:
                best_val_loss = avg_val_loss
                torch.save(model.state_dict(), f'best_{model_type}_model.pth')
                print(f"Epoch {epoch + 1}: 保存当前最佳模型，验证损失: {avg_val_loss:.6f}")

        if (epoch + 1) % 10 == 0:
            current_lr = optimizer.param_groups[0]['lr']
            print(
                f'Epoch [{epoch + 1}/100], Train Loss: {avg_train_loss:.6f}, Val Loss: {avg_val_loss:.6f}, LR: {current_lr:.6f}')

    # 加载最佳模型
    try:
        model.load_state_dict(torch.load(f'best_{model_type}_model.pth'))
        print(f"加载最佳{model_type}模型完成，最佳验证损失: {best_val_loss:.6f}")
    except:
        print(f"无法加载最佳模型，使用当前模型")

    # 测试阶段
    model.eval()
    predictions, actuals = [], []

    with torch.no_grad():
        for batch in test_loader:
            if model_type == 'base':
                x, y = batch
                if torch.isnan(x).any() or torch.isnan(y).any():
                    continue
                output = model(x.unsqueeze(-1))
            else:
                x, factors, y = batch
                if torch.isnan(x).any() or torch.isnan(factors).any() or torch.isnan(y).any():
                    continue
                output = model(x.unsqueeze(-1), factors)

            predictions.extend(output.squeeze().cpu().numpy())
            actuals.extend(y.cpu().numpy())

    predictions = np.array(predictions, dtype=np.float64)
    actuals = np.array(actuals, dtype=np.float64)

    # 反标准化
    predictions = test_dataset.inverse_transform(predictions)
    actuals = test_dataset.inverse_transform(actuals)

    mse = mean_squared_error(actuals, predictions)
    mae = mean_absolute_error(actuals, predictions)

    return predictions, actuals, mse, mae, train_losses[:len(val_losses)]  # 确保长度一致


def prepare_llm_factor_data(df, llm_factors):
    """准备LLM因子数据"""
    # 提取LLM推荐的因子
    available_llm_factors = [f for f in llm_factors if f in df.columns]
    print(f"可用的LLM因子: {available_llm_factors}")

    if not available_llm_factors:
        print("没有可用的LLM因子，使用默认因子")
        available_llm_factors = ['momentum_5', 'rsi', 'macd', 'bb_position', 'price_position']

    # 计算因子值的横截面统计量
    factor_stats = []
    dates = sorted(df['date'].unique())

    for date in dates:
        date_data = df[df['date'] == date]
        if len(date_data) > 0:
            stat_row = {'date': date}
            for factor in available_llm_factors:
                # 计算该因子的横截面统计量
                if factor in date_data.columns:
                    stat_row[f'{factor}_mean'] = date_data[factor].mean()
                    stat_row[f'{factor}_std'] = date_data[factor].std()
                else:
                    stat_row[f'{factor}_mean'] = 0
                    stat_row[f'{factor}_std'] = 0
            factor_stats.append(stat_row)

    factor_df = pd.DataFrame(factor_stats)
    print(f"生成的因子数据长度: {len(factor_df)}")
    return factor_df


def create_enhanced_dataset(ic_df, factor_df, sequence_length=20):
    """创建增强数据集（包含LLM因子）"""
    # 合并IC序列和因子数据
    merged_df = pd.merge(ic_df, factor_df, on='date', how='inner')
    print(f"合并后数据长度: {len(merged_df)}")

    if len(merged_df) == 0:
        print("合并后数据为空，无法创建增强数据集")
        return np.array([]), np.array([]), np.array([])

    # 提取特征
    ic_values = merged_df['ic_value'].values
    factor_columns = [col for col in merged_df.columns if col.endswith('_mean')]

    if not factor_columns:
        print("没有找到因子特征列")
        return np.array([]), np.array([]), np.array([])

    factor_values = merged_df[factor_columns].values

    print(f"因子特征维度: {factor_values.shape}")

    # 创建序列
    X_seq, X_factor, y = [], [], []
    for i in range(len(ic_values) - sequence_length):
        X_seq.append(ic_values[i:i + sequence_length])
        X_factor.append(factor_values[i + sequence_length])  # 使用预测时刻的因子数据
        y.append(ic_values[i + sequence_length])

    if len(X_seq) == 0:
        print("创建的序列为空")
        return np.array([]), np.array([]), np.array([])

    return np.array(X_seq), np.array(X_factor), np.array(y)


def main():
    """主函数"""
    # 配置
    DATA_PATH = r"D:\研究生学习\课程\论文写作\大作业\数据"
    API_KEY = "sk-55e3c55033b749bfb8ecba86618f643c"

    try:
        # 1. 加载数据
        print("加载数据...")
        train_df = pd.read_csv(f"{DATA_PATH}/csi300_train.csv")
        train_df['date'] = pd.to_datetime(train_df['date'])
        print(f"数据形状: {train_df.shape}")

        # 2. 使用LLM分析因子 - 改进版本
        print("使用LLM分析重要因子...")
        analyzer = DeepSeekFactorAnalyzer(API_KEY)
        llm_result = analyzer.analyze_stock_factors(train_df.head())

        print("LLM原始响应:")
        print(llm_result)

        # 提取因子列表
        llm_factors = analyzer.extract_factors_from_response(llm_result)
        print(f"提取的LLM因子: {llm_factors}")

        # 3. 计算IC序列
        ic_df = calculate_ic_series(train_df)

        if len(ic_df) < 30:
            print(f"IC数据不足 ({len(ic_df)})，退出程序")
            return

        # 4. 准备基础LSTM数据
        sequence_length = min(20, len(ic_df) // 3)
        print(f"使用序列长度: {sequence_length}")

        ic_values = ic_df['ic_value'].values

        # 划分数据集
        train_size = int(0.7 * len(ic_values))
        val_size = int(0.15 * len(ic_values))

        train_ic = ic_values[:train_size]
        val_ic = ic_values[train_size:train_size + val_size]
        test_ic = ic_values[train_size + val_size:]

        print(f"数据集划分 - 训练: {len(train_ic)}, 验证: {len(val_ic)}, 测试: {len(test_ic)}")

        # 基础数据集
        train_dataset_base = ICSequenceDataset(pd.DataFrame({'ic_value': train_ic}), sequence_length)
        val_dataset_base = ICSequenceDataset(pd.DataFrame({'ic_value': val_ic}), sequence_length)
        test_dataset_base = ICSequenceDataset(pd.DataFrame({'ic_value': test_ic}), sequence_length)

        # 调整批次大小
        batch_size = min(16, len(train_ic) - sequence_length)
        print(f"使用批次大小: {batch_size}")

        train_loader_base = DataLoader(train_dataset_base, batch_size=batch_size, shuffle=True)
        val_loader_base = DataLoader(val_dataset_base, batch_size=batch_size, shuffle=False)
        test_loader_base = DataLoader(test_dataset_base, batch_size=batch_size, shuffle=False)

        # 5. 训练基础LSTM模型
        print("\n训练基础LSTM模型...")
        base_model = BaseLSTMModel()
        base_pred, base_actual, base_mse, base_mae, base_losses = train_and_evaluate_model(
            base_model, train_loader_base, val_loader_base, test_loader_base, test_dataset_base, 'base'
        )

        # 6. 准备增强LSTM数据
        print("准备增强LSTM数据...")
        factor_df = prepare_llm_factor_data(train_df, llm_factors)

        if len(factor_df) == 0:
            print("无法生成因子数据，使用基础LSTM结果")
            enh_mse, enh_mae = base_mse, base_mae
            enh_pred, enh_actual = base_pred, base_actual
            enh_losses = base_losses
        else:
            X_seq, X_factor, y = create_enhanced_dataset(ic_df, factor_df, sequence_length)

            if len(X_seq) == 0:
                print("增强数据集为空，使用基础LSTM结果")
                enh_mse, enh_mae = base_mse, base_mae
                enh_pred, enh_actual = base_pred, base_actual
                enh_losses = base_losses
            else:
                # 划分增强数据集
                split_idx = int(0.7 * len(X_seq))
                val_idx = int(0.85 * len(X_seq))

                # 创建增强数据加载器
                class EnhancedDataset(Dataset):
                    def __init__(self, X_seq, X_factor, y):
                        self.X_seq = X_seq
                        self.X_factor = X_factor
                        self.y = y

                    def __len__(self):
                        return len(self.X_seq)

                    def __getitem__(self, idx):
                        return (torch.FloatTensor(self.X_seq[idx]),
                                torch.FloatTensor(self.X_factor[idx]),
                                torch.FloatTensor([self.y[idx]]))

                train_dataset_enhanced = EnhancedDataset(X_seq[:split_idx], X_factor[:split_idx], y[:split_idx])
                val_dataset_enhanced = EnhancedDataset(X_seq[split_idx:val_idx], X_factor[split_idx:val_idx],
                                                       y[split_idx:val_idx])
                test_dataset_enhanced = EnhancedDataset(X_seq[val_idx:], X_factor[val_idx:], y[val_idx:])

                train_loader_enhanced = DataLoader(train_dataset_enhanced, batch_size=batch_size, shuffle=True)
                val_loader_enhanced = DataLoader(val_dataset_enhanced, batch_size=batch_size, shuffle=False)
                test_loader_enhanced = DataLoader(test_dataset_enhanced, batch_size=batch_size, shuffle=False)

                # 7. 训练增强LSTM模型
                print("训练增强LSTM模型（使用LLM因子）...")
                enhanced_model = EnhancedLSTMModel(factor_size=X_factor.shape[1])
                enh_pred, enh_actual, enh_mse, enh_mae, enh_losses = train_and_evaluate_model(
                    enhanced_model, train_loader_enhanced, val_loader_enhanced, test_loader_enhanced,
                    test_dataset_base, 'enhanced'
                )

        # 8. 结果比较和可视化
        print("\n" + "=" * 60)
        print("LSTM模型性能比较")
        print("=" * 60)
        print(f"基础LSTM模型 (仅IC序列):")
        print(f"  MSE: {base_mse:.6f}")
        print(f"  MAE: {base_mae:.6f}")

        print(f"\n增强LSTM模型 (IC序列 + LLM因子):")
        print(f"  MSE: {enh_mse:.6f}")
        print(f"  MAE: {enh_mae:.6f}")

        improvement = (base_mse - enh_mse) / base_mse * 100 if base_mse > 0 else 0
        print(f"\n性能提升: {improvement:.2f}%")

        # 可视化结果
        plt.figure(figsize=(15, 10))

        # 训练损失对比
        plt.subplot(2, 2, 1)
        min_len = min(len(base_losses), len(enh_losses))
        if min_len > 0:
            plt.plot(range(min_len), base_losses[:min_len], label='基础LSTM', alpha=0.7)
            plt.plot(range(min_len), enh_losses[:min_len], label='增强LSTM', alpha=0.7)
            plt.title('训练损失对比')
            plt.xlabel('训练轮次')
            plt.ylabel('损失')
            plt.legend()
            plt.grid(True, alpha=0.3)

        # 预测结果对比
        plt.subplot(2, 2, 2)
        plot_len = min(50, len(base_actual), len(enh_actual))
        if plot_len > 0:
            plt.plot(range(plot_len), base_actual[:plot_len], label='实际IC值', color='black', linewidth=2)
            plt.plot(range(plot_len), base_pred[:plot_len], label='基础LSTM预测', alpha=0.7)
            plt.plot(range(plot_len), enh_pred[:plot_len], label='增强LSTM预测', alpha=0.7)
            plt.title('IC值预测结果对比')
            plt.xlabel('时间步')
            plt.ylabel('IC值')
            plt.legend()
            plt.grid(True, alpha=0.3)

        # 模型性能对比
        plt.subplot(2, 2, 3)
        models = ['基础LSTM', '增强LSTM']
        mse_scores = [base_mse, enh_mse]
        bars = plt.bar(models, mse_scores, color=['blue', 'orange'])
        plt.title('模型MSE对比')
        plt.ylabel('MSE')

        # 在柱状图上显示数值
        for bar, score in zip(bars, mse_scores):
            plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.0001,
                     f'{score:.6f}', ha='center', va='bottom')

        # 残差对比
        plt.subplot(2, 2, 4)
        if len(base_actual) > 0 and len(enh_actual) > 0:
            base_residuals = base_actual - base_pred
            enh_residuals = enh_actual - enh_pred
            plt.hist(base_residuals, bins=30, alpha=0.5, label='基础LSTM残差')
            plt.hist(enh_residuals, bins=30, alpha=0.5, label='增强LSTM残差')
            plt.axvline(x=0, color='red', linestyle='--')
            plt.title('预测残差分布对比')
            plt.xlabel('残差')
            plt.ylabel('频数')
            plt.legend()

        plt.tight_layout()
        plt.savefig('lstm_comparison_results.png', dpi=300, bbox_inches='tight')
        plt.show()

        # 保存结果
        results = {
            'base_lstm': {
                'mse': float(base_mse),
                'mae': float(base_mae)
            },
            'enhanced_lstm': {
                'mse': float(enh_mse),
                'mae': float(enh_mae)
            },
            'improvement_percentage': float(improvement),
            'llm_factors': llm_factors,
            'llm_analysis': llm_result
        }

        with open('lstm_comparison_results.json', 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)

        print(f"\n结果已保存到 lstm_comparison_results.json")
        print(f"LLM分析的关键因子: {llm_factors}")

    except Exception as e:
        print(f"程序执行出错: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()