import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.distributions import Categorical
import numpy as np


class FastActorNetwork(nn.Module):
    """快速Actor网络 - 减小网络规模"""

    def __init__(self, state_dim, action_dim, hidden_dim=64):  # 减小隐藏层
        super(FastActorNetwork, self).__init__()
        self.network = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
            nn.Softmax(dim=-1)
        )

    def forward(self, state):
        return self.network(state)


class FastCriticNetwork(nn.Module):
    """快速Critic网络 - 减小网络规模"""

    def __init__(self, state_dim, hidden_dim=64):
        super(FastCriticNetwork, self).__init__()
        self.network = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, state):
        return self.network(state)


class FastBasePPO:
    """快速基础PPO算法"""

    def __init__(self, state_dim, action_dim, lr=1e-3, gamma=0.99,  # 提高学习率
                 clip_epsilon=0.2, ppo_epochs=3, batch_size=32):  # 减少参数
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.clip_epsilon = clip_epsilon
        self.ppo_epochs = ppo_epochs
        self.batch_size = batch_size

        # 网络
        self.actor = FastActorNetwork(state_dim, action_dim)
        self.critic = FastCriticNetwork(state_dim)

        # 优化器
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=lr)

        # 经验缓冲区
        self.memory = deque(maxlen=1000)  # 限制缓冲区大小

    def select_action(self, state):
        """选择动作"""
        state_tensor = torch.FloatTensor(state).unsqueeze(0)

        with torch.no_grad():
            action_probs = self.actor(state_tensor)
            value = self.critic(state_tensor)

        dist = Categorical(action_probs)
        action = dist.sample()
        log_prob = dist.log_prob(action)

        return action.item(), log_prob.item(), value.item()

    def store_transition(self, state, action, reward, next_state, done, log_prob, value):
        """存储经验"""
        self.memory.append((state, action, reward, next_state, done, log_prob, value))

    def update(self):
        """快速更新网络"""
        if len(self.memory) < self.batch_size:
            return

        # 准备批量数据
        batch = list(self.memory)
        states = torch.FloatTensor([x[0] for x in batch])
        actions = torch.LongTensor([x[1] for x in batch])
        rewards = torch.FloatTensor([x[2] for x in batch])
        next_states = torch.FloatTensor([x[3] for x in batch])
        dones = torch.BoolTensor([x[4] for x in batch])
        old_log_probs = torch.FloatTensor([x[5] for x in batch])
        old_values = torch.FloatTensor([x[6] for x in batch])

        # 计算回报（简化版本）
        returns = self._compute_returns(rewards, dones)

        # 单次PPO更新（减少迭代次数）
        action_probs = self.actor(states)
        dist = Categorical(action_probs)
        new_log_probs = dist.log_prob(actions)

        # 策略损失
        ratios = torch.exp(new_log_probs - old_log_probs)
        advantages = returns - old_values
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        surr1 = ratios * advantages
        surr2 = torch.clamp(ratios, 1 - self.clip_epsilon, 1 + self.clip_epsilon) * advantages
        actor_loss = -torch.min(surr1, surr2).mean()

        # 价值损失
        values = self.critic(states).squeeze()
        critic_loss = F.mse_loss(values, returns)

        # 更新
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # 清空部分经验
        if len(self.memory) > 500:
            for _ in range(100):
                if self.memory:
                    self.memory.popleft()

    def _compute_returns(self, rewards, dones):
        """简化回报计算"""
        returns = []
        R = 0

        for r, done in zip(reversed(rewards), reversed(dones)):
            if done:
                R = r
            else:
                R = r + self.gamma * R
            returns.insert(0, R)

        return torch.FloatTensor(returns)

    def save_model(self, path):
        """保存模型"""
        torch.save({
            'actor_state_dict': self.actor.state_dict(),
            'critic_state_dict': self.critic.state_dict(),
        }, path)

    def load_model(self, path):
        """加载模型"""
        checkpoint = torch.load(path)
        self.actor.load_state_dict(checkpoint['actor_state_dict'])
        self.critic.load_state_dict(checkpoint['critic_state_dict'])