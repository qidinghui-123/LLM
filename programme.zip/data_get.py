import pandas as pd
import baostock as bs
import os
from datetime import datetime, timedelta
import numpy as np
import time
import requests
from tqdm import tqdm


def login_baostock():
    """登录baostock系统"""
    lg = bs.login()
    if lg.error_code != '0':
        print(f'登录失败: {lg.error_msg}')
        return False
    print('baostock登录成功')
    return True


def logout_baostock():
    """登出baostock系统"""
    bs.logout()
    print('baostock登出成功')


def get_csi300_components():
    """
    获取CSI300成分股列表
    返回股票代码列表
    """
    print("正在获取CSI300成分股列表...")

    # 从网络获取CSI300成分股（这里使用一个公开的数据源）
    try:
        # 方法1: 使用东方财富网的数据
        url = "http://quote.eastmoney.com/center/boardlist.html#boards-BK0500"

        # 由于直接获取成分股比较复杂，我们使用一个已知的CSI300成分股列表
        # 在实际应用中，您可能需要使用专业的财经数据API
        csi300_codes = [
            "sh.600000", "sh.600009", "sh.600010", "sh.600011", "sh.600015",
            "sh.600016", "sh.600018", "sh.600019", "sh.600025", "sh.600028",
            "sh.600029", "sh.600030", "sh.600031", "sh.600036", "sh.600038",
            "sh.600048", "sh.600050", "sh.600061", "sh.600066", "sh.600068",
            "sh.600085", "sh.600089", "sh.600104", "sh.600109", "sh.600111",
            "sh.600115", "sh.600118", "sh.600150", "sh.600176", "sh.600177",
            "sh.600183", "sh.600188", "sh.600196", "sh.600208", "sh.600219",
            "sh.600221", "sh.600233", "sh.600271", "sh.600276", "sh.600297",
            "sh.600309", "sh.600332", "sh.600340", "sh.600346", "sh.600362",
            "sh.600383", "sh.600390", "sh.600398", "sh.600406", "sh.600436",
            "sh.600438", "sh.600482", "sh.600487", "sh.600489", "sh.600498",
            "sh.600516", "sh.600519", "sh.600522", "sh.600536", "sh.600547",
            "sh.600570", "sh.600585", "sh.600588", "sh.600606", "sh.600637",
            "sh.600655", "sh.600660", "sh.600674", "sh.600690", "sh.600703",
            "sh.600705", "sh.600741", "sh.600745", "sh.600760", "sh.600763",
            "sh.600795", "sh.600809", "sh.600837", "sh.600848", "sh.600867",
            "sh.600886", "sh.600887", "sh.600893", "sh.600900", "sh.600905",
            "sh.600918", "sh.600919", "sh.600926", "sh.600928", "sh.600933",
            "sh.600938", "sh.600939", "sh.600958", "sh.600989", "sh.600999",
            "sh.601006", "sh.601008", "sh.601009", "sh.601012", "sh.601018",
            "sh.601021", "sh.601066", "sh.601077", "sh.601088", "sh.601099",
            "sh.601100", "sh.601108", "sh.601111", "sh.601117", "sh.601138",
            "sh.601155", "sh.601166", "sh.601169", "sh.601186", "sh.601198",
            "sh.601211", "sh.601216", "sh.601225", "sh.601229", "sh.601231",
            "sh.601236", "sh.601238", "sh.601288", "sh.601318", "sh.601319",
            "sh.601328", "sh.601336", "sh.601360", "sh.601377", "sh.601390",
            "sh.601398", "sh.601555", "sh.601577", "sh.601600", "sh.601601",
            "sh.601607", "sh.601618", "sh.601628", "sh.601633", "sh.601658",
            "sh.601665", "sh.601668", "sh.601669", "sh.601688", "sh.601698",
            "sh.601699", "sh.601717", "sh.601728", "sh.601766", "sh.601788",
            "sh.601800", "sh.601808", "sh.601816", "sh.601818", "sh.601828",
            "sh.601838", "sh.601857", "sh.601865", "sh.601868", "sh.601872",
            "sh.601877", "sh.601878", "sh.601881", "sh.601888", "sh.601898",
            "sh.601899", "sh.601901", "sh.601916", "sh.601919", "sh.601933",
            "sh.601939", "sh.601949", "sh.601955", "sh.601958", "sh.601966",
            "sh.601985", "sh.601988", "sh.601989", "sh.601992", "sh.601995",
            "sh.601998", "sh.603019", "sh.603087", "sh.603160", "sh.603195",
            "sh.603259", "sh.603260", "sh.603288", "sh.603369", "sh.603501",
            "sh.603508", "sh.603515", "sh.603517", "sh.603658", "sh.603799",
            "sh.603806", "sh.603833", "sh.603858", "sh.603882", "sh.603899",
            "sh.603901", "sh.603986", "sh.603993", "sz.000001", "sz.000002",
            "sz.000063", "sz.000066", "sz.000069", "sz.000100", "sz.000157",
            "sz.000166", "sz.000333", "sz.000338", "sz.000425", "sz.000538",
            "sz.000568", "sz.000596", "sz.000625", "sz.000627", "sz.000629",
            "sz.000630", "sz.000651", "sz.000656", "sz.000661", "sz.000671",
            "sz.000703", "sz.000708", "sz.000709", "sz.000723", "sz.000725",
            "sz.000728", "sz.000738", "sz.000768", "sz.000776", "sz.000783",
            "sz.000786", "sz.000792", "sz.000800", "sz.000825", "sz.000826",
            "sz.000858", "sz.000876", "sz.000877", "sz.000895", "sz.000898",
            "sz.000938", "sz.000959", "sz.000961", "sz.000963", "sz.000977",
            "sz.001979", "sz.002001", "sz.002007", "sz.002008", "sz.002024",
            "sz.002027", "sz.002032", "sz.002044", "sz.002049", "sz.002050",
            "sz.002056", "sz.002064", "sz.002074", "sz.002079", "sz.002129",
            "sz.002142", "sz.002153", "sz.002179", "sz.002202", "sz.002230",
            "sz.002236", "sz.002241", "sz.002252", "sz.002271", "sz.002304",
            "sz.002311", "sz.002352", "sz.002371", "sz.002410", "sz.002414",
            "sz.002415", "sz.002422", "sz.002456", "sz.002460", "sz.002463",
            "sz.002466", "sz.002475", "sz.002493", "sz.002555", "sz.002568",
            "sz.002594", "sz.002601", "sz.002602", "sz.002607", "sz.002624",
            "sz.002673", "sz.002714", "sz.002736", "sz.002738", "sz.002739",
            "sz.002773", "sz.002812", "sz.002821", "sz.002831", "sz.002839",
            "sz.002841", "sz.002916", "sz.002920", "sz.002925", "sz.002936",
            "sz.002938", "sz.002939", "sz.002945", "sz.002958", "sz.002966",
            "sz.002967", "sz.003816", "sz.300001", "sz.300014", "sz.300015",
            "sz.300033", "sz.300059", "sz.300122", "sz.300124", "sz.300136",
            "sz.300142", "sz.300144", "sz.300146", "sz.300207", "sz.300223",
            "sz.300274", "sz.300316", "sz.300347", "sz.300408", "sz.300413",
            "sz.300433", "sz.300498", "sz.300529", "sz.300558", "sz.300568",
            "sz.300595", "sz.300601", "sz.300628", "sz.300661", "sz.300676",
            "sz.300677", "sz.300682", "sz.300759", "sz.300763", "sz.300769",
            "sz.300773", "sz.300782", "sz.300783", "sz.300832", "sz.300866",
            "sz.300888", "sz.300896", "sz.300919", "sz.300957", "sz.300979"
        ]

        print(f"成功获取 {len(csi300_codes)} 只CSI300成分股")
        return csi300_codes

    except Exception as e:
        print(f"获取CSI300成分股失败: {e}")
        # 返回一个较小的测试列表
        return ["sh.600000", "sh.600036", "sh.601318", "sz.000001", "sz.000858", "sh.600519"]


def get_stock_data(stock_code, start_date, end_date, max_retries=3):
    """
    获取股票历史数据，带重试机制
    :param stock_code: 股票代码
    :param start_date: 开始日期
    :param end_date: 结束日期
    :param max_retries: 最大重试次数
    :return: DataFrame
    """
    """以下是frequency的参数
        "d" - 日线数据 (daily)
        "w" - 周线数据 (weekly)
        "m" - 月线数据 (monthly)
        "5" - 5分钟线
        "15" - 15分钟线
        "30" - 30分钟线
        "60" - 60分钟线
    """
    for attempt in range(max_retries):
        try:
            # 查询股票行情数据
            rs = bs.query_history_k_data_plus(
                stock_code,
                "date,code,open,high,low,close,volume,amount,turn,tradestatus,pctChg",
                start_date=start_date,
                end_date=end_date,
                frequency="d",
                adjustflag="3"  # 复权类型：3-不复权
            )

            if rs.error_code != '0':
                print(f'查询{stock_code}数据失败: {rs.error_msg}')
                return None

            # 转换为DataFrame
            data_list = []
            while (rs.error_code == '0') & rs.next():
                data_list.append(rs.get_row_data())

            if not data_list:
                print(f"股票{stock_code}没有数据")
                return None

            df = pd.DataFrame(data_list, columns=rs.fields)

            # 数据类型转换
            numeric_columns = ['open', 'high', 'low', 'close', 'volume', 'amount', 'turn', 'pctChg']
            for col in numeric_columns:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')#将错误值改为nan

            df['date'] = pd.to_datetime(df['date'])
            df = df.sort_values('date').reset_index(drop=True)

            # 只保留交易状态为1的数据（正常交易）
            if 'tradestatus' in df.columns:
                df = df[df['tradestatus'] == '1']

            return df

        except Exception as e:
            print(f"获取{stock_code}数据失败 (尝试 {attempt + 1}/{max_retries}): {e}")
            if attempt < max_retries - 1:
                time.sleep(2)  # 等待2秒后重试
            else:
                return None


def calculate_technical_indicators(df):
    """
    计算技术指标
    :param df: 原始数据DataFrame
    :return: 添加技术指标的DataFrame
    """
    # 确保数据按日期排序
    df = df.sort_values('date').reset_index(drop=True)

    # 价格变化率
    df['price_change'] = df['close'].pct_change()
    df['price_change_5'] = df['close'].pct_change(5)
    df['future_return_1'] = df['close'].pct_change().shift(-1)  # 下一日收益率
    df['future_return_5'] = df['close'].pct_change(5).shift(-5)  # 未来5日收益率

    # 移动平均线
    windows = [5, 10, 20, 60]
    for window in windows:
        df[f'ma_{window}'] = df['close'].rolling(window=window).mean()
        df[f'volume_ma_{window}'] = df['volume'].rolling(window=window).mean()

    # 相对强弱指标 (RSI)
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / (loss + 1e-8)  # 避免除零
    df['rsi'] = 100 - (100 / (1 + rs))

    # 布林带
    df['bb_middle'] = df['close'].rolling(window=20).mean()
    bb_std = df['close'].rolling(window=20).std()
    df['bb_upper'] = df['bb_middle'] + 2 * bb_std
    df['bb_lower'] = df['bb_middle'] - 2 * bb_std
    df['bb_position'] = (df['close'] - df['bb_lower']) / (df['bb_upper'] - df['bb_lower'] + 1e-8)

    # 波动率
    df['volatility_5'] = df['price_change'].rolling(window=5).std()
    df['volatility_10'] = df['price_change'].rolling(window=10).std()
    df['volatility_20'] = df['price_change'].rolling(window=20).std()

    # 成交量比率
    df['volume_ratio'] = df['volume'] / df['volume_ma_5']

    # 价格高低区间位置
    df['high_10'] = df['high'].rolling(window=10).max()
    df['low_10'] = df['low'].rolling(window=10).min()
    df['price_position'] = (df['close'] - df['low_10']) / (df['high_10'] - df['low_10'] + 1e-8)

    # MACD指标
    exp12 = df['close'].ewm(span=12, adjust=False).mean()
    exp26 = df['close'].ewm(span=26, adjust=False).mean()
    df['macd'] = exp12 - exp26
    df['macd_signal'] = df['macd'].ewm(span=9, adjust=False).mean()
    df['macd_hist'] = df['macd'] - df['macd_signal']

    # 动量指标
    df['momentum_5'] = df['close'] / df['close'].shift(5) - 1
    df['momentum_10'] = df['close'] / df['close'].shift(10) - 1
    df['momentum_20'] = df['close'] / df['close'].shift(20) - 1

    # 删除NaN值
    df = df.dropna().reset_index(drop=True)

    return df


def split_dataset_by_dates(df):
    """
    按指定日期范围划分数据集
    :param df: 原始数据
    :return: 划分后的数据集
    """
    # 定义日期范围
    train_start = '2015-01-01'
    train_end = '2021-12-31'
    val_start = '2022-01-01'
    val_end = '2022-12-31'
    test_start = '2023-01-01'
    test_end = '2024-06-30'  # 使用当前可获得的数据

    # 转换为日期类型
    train_start_date = pd.to_datetime(train_start)
    train_end_date = pd.to_datetime(train_end)
    val_start_date = pd.to_datetime(val_start)
    val_end_date = pd.to_datetime(val_end)
    test_start_date = pd.to_datetime(test_start)
    test_end_date = pd.to_datetime(test_end)

    # 按日期范围划分数据集
    train_df = df[(df['date'] >= train_start_date) & (df['date'] <= train_end_date)].copy()
    val_df = df[(df['date'] >= val_start_date) & (df['date'] <= val_end_date)].copy()
    test_df = df[(df['date'] >= test_start_date) & (df['date'] <= test_end_date)].copy()

    print(f"数据集按日期划分完成:")
    print(f"训练集 ({train_start} 到 {train_end}): {len(train_df)} 条数据")
    print(f"验证集 ({val_start} 到 {val_end}): {len(val_df)} 条数据")
    print(f"测试集 ({test_start} 到 {test_end}): {len(test_df)} 条数据")

    return train_df, val_df, test_df


def save_datasets(train_df, val_df, test_df, save_path, prefix="csi300"):
    """
    保存数据集到CSV文件
    :param train_df: 训练集
    :param val_df: 验证集
    :param test_df: 测试集
    :param save_path: 保存路径
    :param prefix: 文件前缀
    """
    # 确保保存路径存在
    os.makedirs(save_path, exist_ok=True)

    # 生成文件名
    train_filename = os.path.join(save_path, f'{prefix}_train.csv')
    val_filename = os.path.join(save_path, f'{prefix}_validation.csv')
    test_filename = os.path.join(save_path, f'{prefix}_test.csv')
    summary_filename = os.path.join(save_path, f'{prefix}_data_summary.txt')

    try:
        # 保存CSV文件
        train_df.to_csv(train_filename, index=False, encoding='utf-8')
        val_df.to_csv(val_filename, index=False, encoding='utf-8')
        test_df.to_csv(test_filename, index=False, encoding='utf-8')

        print(f"\n数据已保存到:")
        print(f"训练集: {train_filename}")
        print(f"验证集: {val_filename}")
        print(f"测试集: {test_filename}")

        # 创建数据摘要文件
        with open(summary_filename, 'w', encoding='utf-8') as f:
            f.write("CSI300股票数据摘要\n")
            f.write("=" * 50 + "\n")
            f.write(f"数据获取时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"股票数量: {train_df['code'].nunique()}\n")
            f.write(f"总数据量: {len(train_df) + len(val_df) + len(test_df)}\n\n")

            f.write("数据集划分:\n")
            f.write(f"训练集 (2015-01-01 到 2021-12-31): {len(train_df)} 条\n")
            f.write(f"验证集 (2022-01-01 到 2022-12-31): {len(val_df)} 条\n")
            f.write(f"测试集 (2023-01-01 到 2024-06-30): {len(test_df)} 条\n\n")

            f.write("特征列:\n")
            for col in train_df.columns:
                f.write(f"  - {col}\n")

            f.write(f"\n数据统计:\n")
            f.write(f"训练集日期范围: {train_df['date'].min()} 到 {train_df['date'].max()}\n")
            f.write(f"验证集日期范围: {val_df['date'].min()} 到 {val_df['date'].max()}\n")
            f.write(f"测试集日期范围: {test_df['date'].min()} 到 {test_df['date'].max()}\n")
            f.write(f"训练集股票数量: {train_df['code'].nunique()}\n")
            f.write(f"验证集股票数量: {val_df['code'].nunique()}\n")
            f.write(f"测试集股票数量: {test_df['code'].nunique()}\n")

        print(f"数据摘要: {summary_filename}")

    except Exception as e:
        print(f"保存文件时出错: {e}")


def data_quality_check(df, dataset_name):
    """
    数据质量检查
    :param df: 数据集
    :param dataset_name: 数据集名称
    """
    print(f"\n{dataset_name}数据质量检查:")
    print(f"数据形状: {df.shape}")
    print(f"股票数量: {df['code'].nunique()}")
    print(f"数据时间范围: {df['date'].min().strftime('%Y-%m-%d')} 到 {df['date'].max().strftime('%Y-%m-%d')}")

    # 检查缺失值
    missing_values = df.isnull().sum()
    if missing_values.sum() > 0:
        print("缺失值统计:")
        for col, count in missing_values.items():
            if count > 0:
                print(f"  {col}: {count} 个缺失值")
    else:
        print("无缺失值")

    return df


def analyze_returns(df, dataset_name):
    """
    分析收益率特征
    :param df: 数据集
    :param dataset_name: 数据集名称
    """
    if 'future_return_1' in df.columns:
        returns = df['future_return_1'].dropna()
        if len(returns) > 0:
            print(f"\n{dataset_name}未来一日收益率分析:")
            print(f"均值: {returns.mean():.4f}")
            print(f"标准差: {returns.std():.4f}")
            print(f"夏普比率: {returns.mean() / returns.std():.4f}" if returns.std() > 0 else "夏普比率: 无穷大")
            print(f"正收益比例: {(returns > 0).sum() / len(returns):.2%}")


def main():
    """主函数"""
    # 配置参数
    start_date = "2015-01-01"
    end_date = "2024-06-30"  # 使用当前可获得的数据
    save_path = r"D:\研究生学习\课程\论文写作\大作业\数据"

    try:
        # 1. 登录baostock
        if not login_baostock():
            return

        # 2. 获取CSI300成分股列表
        stock_codes = get_csi300_components()
        #print(1)
        #print(stock_codes)
        #print(2)
        if not stock_codes:
            print("无法获取CSI300成分股列表")
            return

        # 3. 分批获取股票数据（避免请求过于频繁）
        print(f"\n开始获取 {len(stock_codes)} 只CSI300成分股数据...")
        all_data = []
        failed_codes = []

        # 使用进度条显示下载进度
        for i, code in enumerate(tqdm(stock_codes, desc="下载股票数据")):
    #同时获取索引和元素值，i: 当前元素的索引（从0开始）code: 当前股票代码
            df = get_stock_data(code, start_date, end_date)
            if df is not None and len(df) > 0:
                all_data.append(df)
            else:
                failed_codes.append(code)

            # 每10只股票暂停1秒，避免请求过于频繁
            if (i + 1) % 10 == 0:
                time.sleep(1)

        print(f"\n成功获取 {len(all_data)} 只股票数据，失败 {len(failed_codes)} 只")
        if failed_codes:
            print(f"失败的股票代码: {failed_codes}")

        if not all_data:
            print("未获取到任何股票数据")
            return

        # 4. 合并所有股票数据
        combined_df = pd.concat(all_data, ignore_index=True)
        print(f"\n合并后总数据量: {len(combined_df)} 条")

        # 5. 按股票分组计算技术指标
        print("\n开始计算技术指标...")
        grouped = combined_df.groupby('code')
        processed_dfs = []

        for code, group in tqdm(grouped, desc="计算技术指标"):
            try:
                processed_group = calculate_technical_indicators(group)
                processed_dfs.append(processed_group)
            except Exception as e:
                print(f"计算{code}技术指标失败: {e}")

        df_processed = pd.concat(processed_dfs, ignore_index=True)

        # 6. 数据质量检查
        data_quality_check(df_processed, "原始")

        # 7. 按日期划分数据集
        train_df, val_df, test_df = split_dataset_by_dates(df_processed)

        # 8. 对各数据集进行质量检查
        train_df = data_quality_check(train_df, "训练集")
        val_df = data_quality_check(val_df, "验证集")
        test_df = data_quality_check(test_df, "测试集")

        # 9. 分析收益率特征
        analyze_returns(train_df, "训练集")
        analyze_returns(val_df, "验证集")
        analyze_returns(test_df, "测试集")

        # 10. 保存数据集
        save_datasets(train_df, val_df, test_df, save_path, "csi300")

        print("\nCSI300数据处理完成！")

    except Exception as e:
        print(f"程序执行出错: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # 确保登出
        logout_baostock()


if __name__ == "__main__":
    main()