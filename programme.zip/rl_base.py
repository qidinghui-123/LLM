import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Categorical
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from collections import deque
import warnings

warnings.filterwarnings('ignore')

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


class FastFactorMiningEnvironment:
    """快速版本的因子挖掘环境"""

    def __init__(self, data, lookback_window=10, transaction_cost=0.001):  # 减小窗口
        self.data = data
        self.lookback_window = lookback_window
        self.transaction_cost = transaction_cost
        self.scaler = StandardScaler()

        # 基础因子池 - 选择最重要的几个因子
        self.base_factors = ['momentum_5', 'rsi', 'macd', 'bb_position', 'price_position']

        # 确保因子存在
        self.available_factors = [f for f in self.base_factors if f in data.columns]
        print(f"可用因子数量: {len(self.available_factors)}")

        # 预计算
        self._precompute_data()
        self.reset()

    def _precompute_data(self):
        """预计算所有数据，避免重复计算"""
        print("预计算环境数据...")

        # 采样数据 - 保持股票数量但减少时间步长
        dates = sorted(self.data['date'].unique())
        sampled_dates = dates[::2]  # 每隔一天采样
        self.sampled_data = self.data[self.data['date'].isin(sampled_dates)].copy()
        print(f"采样后数据量: {len(self.sampled_data)} (原数据: {len(self.data)})")

        # 预计算IC序列
        self.ic_series = self._calculate_fast_ic_series()

        # 预计算特征矩阵
        self._precompute_features()

    def _calculate_fast_ic_series(self):
        """快速计算IC序列"""
        print("快速计算IC序列...")
        ic_series = []
        dates = sorted(self.sampled_data['date'].unique())

        # 使用向量化计算
        for i in range(1, min(len(dates), 100)):  # 只计算前100个日期
            current_date = dates[i]
            prev_date = dates[i - 1]

            prev_data = self.sampled_data[self.sampled_data['date'] == prev_date]
            current_data = self.sampled_data[self.sampled_data['date'] == current_date]

            if len(prev_data) > 5 and len(current_data) > 5:
                merged = pd.merge(prev_data[['code'] + self.available_factors],
                                  current_data[['code', 'future_return_1']],
                                  on='code')

                if len(merged) > 5:
                    ic_values = []
                    for factor in self.available_factors:
                        try:
                            ic = merged[factor].corr(merged['future_return_1'])
                            if not np.isnan(ic):
                                ic_values.append(abs(ic))  # 取绝对值
                        except:
                            continue

                    ic_series.append(np.mean(ic_values) if ic_values else 0)
                else:
                    ic_series.append(0)
            else:
                ic_series.append(0)

        # 填充剩余部分
        while len(ic_series) < len(self.sampled_data):
            ic_series.append(0)

        return ic_series[:len(self.sampled_data)]

    def _precompute_features(self):
        """预计算特征矩阵"""
        print("预计算特征矩阵...")
        feature_data = []

        # 只计算必要的步骤
        max_steps = min(2000, len(self.sampled_data) - self.lookback_window)  # 限制最大步数

        for i in range(self.lookback_window, self.lookback_window + max_steps):
            features = []
            # 技术因子
            for factor in self.available_factors:
                features.append(self.sampled_data[factor].iloc[i])
            # IC值
            features.append(self.ic_series[i] if i < len(self.ic_series) else 0)
            feature_data.append(features)

        self.scaled_features = self.scaler.fit_transform(feature_data)
        self.max_steps = max_steps
        print(f"预计算特征完成，总步数: {self.max_steps}")

    def reset(self):
        """重置环境"""
        self.current_step = 0
        self.portfolio_value = 1.0
        self.positions = 0
        self.done = False
        self.episode_return = 0

        return self._get_state()

    def _get_state(self):
        """获取当前状态"""
        if self.current_step >= len(self.scaled_features):
            return np.zeros(len(self.available_factors) + 2)  # 因子数 + IC值 + 仓位

        state = self.scaled_features[self.current_step].copy()
        state = np.append(state, self.positions)

        return state

    def step(self, action):
        """快速执行动作"""
        if self.done:
            return self._get_state(), 0, True, {}

        prev_value = self.portfolio_value
        prev_position = self.positions

        # 获取当前数据
        actual_idx = self.current_step + self.lookback_window
        if actual_idx < len(self.sampled_data):
            current_data = self.sampled_data.iloc[actual_idx]
            current_return = current_data.get('future_return_1', 0)
        else:
            current_return = 0

        # 执行交易
        if action == 0:  # 做空
            self.positions = -1
        elif action == 1:  # 空仓
            self.positions = 0
        else:  # 做多
            self.positions = 1

        # 计算收益
        position_change = abs(self.positions - prev_position)
        trade_cost = position_change * self.transaction_cost
        position_return = self.positions * current_return

        # 更新组合价值
        self.portfolio_value *= (1 + position_return - trade_cost)
        step_reward = position_return - trade_cost
        self.episode_return += step_reward

        # 更新步骤
        self.current_step += 1

        # 检查结束条件
        if self.current_step >= self.max_steps - 1:
            self.done = True

        # 简化奖励
        reward = step_reward * 10  # 基础奖励

        # IC一致性奖励（简化）
        if self.current_step < len(self.ic_series):
            current_ic = self.ic_series[self.current_step + self.lookback_window]
            if current_ic * position_return > 0:
                reward += current_ic * 2

        return self._get_state(), reward, self.done, {
            'portfolio_value': self.portfolio_value,
            'position': self.positions,
            'step_return': step_reward
        }